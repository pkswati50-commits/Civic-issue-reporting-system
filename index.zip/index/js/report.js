/* =========================================================
   report.js — citizen report form + nearby reports strip
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {

  /* ---------- mobile nav ---------- */
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks  = document.querySelector(".nav-links");
  navToggle?.addEventListener("click", () => {
    navLinks.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", navLinks.classList.contains("open"));
  });

  /* ---------- category selection + severity readout ---------- */
  const categoryGrid  = document.getElementById("categoryGrid");
  const severityCopy  = document.getElementById("severityCopy");
  const severityPill  = document.getElementById("severityPill");
  const sevOverride   = document.getElementById("sevOverride");
  const sevChips      = document.getElementById("sevOverrideChips");
  let selectedCategory = null;
  let manualSeverity   = "auto"; // "auto" | "low" | "medium" | "high" | "critical"

  function renderCategoryChips() {
    categoryGrid.innerHTML = Object.entries(CATEGORY_WEIGHTS).map(([key, c]) => `
      <label class="category-chip" data-key="${key}">
        <input type="radio" name="category" value="${key}" />
        <span class="ic">${c.icon}</span>
        <span>${c.label}</span>
      </label>
    `).join("");
  }

  function effectiveSeverity() {
    if (manualSeverity !== "auto") return { tier: manualSeverity, label: manualSeverity.charAt(0).toUpperCase() + manualSeverity.slice(1), score: 0 };
    if (!selectedCategory) return null;
    return computeSeverity(selectedCategory, 0);
  }

  function updateSeverityReadout() {
    const sev = effectiveSeverity();
    if (!sev) {
      severityPill.innerHTML = `<span class="dot"></span> Select a category`;
      severityPill.className = "sev-pill";
      severityCopy.innerHTML = `Severity is <b>inferred automatically</b> from the issue category and how many nearby citizens confirm it.`;
      sevOverride.style.display = "none";
      return;
    }
    severityPill.className = `sev-pill ${sev.tier}`;
    severityPill.innerHTML = `<span class="dot"></span> ${sev.label} severity${manualSeverity !== "auto" ? " (manual override)" : " (auto)"}`;
    if (selectedCategory) {
      const cat = CATEGORY_WEIGHTS[selectedCategory];
      severityCopy.innerHTML = manualSeverity !== "auto"
        ? `You've set severity manually to <b>${sev.label}</b>. It overrides the auto-computed value for this report.`
        : `Based on <b>${cat.label}</b>, this starts at <b>${sev.label.toLowerCase()}</b> severity with a <b>${cat.slaHours}h</b> SLA. Confirmations can push it higher.`;
      sevOverride.style.display = "block";
    }
  }

  /* severity override chip clicks */
  sevChips?.addEventListener("click", (e) => {
    const btn = e.target.closest(".sev-chip");
    if (!btn) return;
    manualSeverity = btn.dataset.sev;
    sevChips.querySelectorAll(".sev-chip").forEach(c => c.classList.remove("active"));
    btn.classList.add("active");
    updateSeverityReadout();
  });

  categoryGrid?.addEventListener("click", (e) => {
    const chip = e.target.closest(".category-chip");
    if (!chip) return;
    categoryGrid.querySelectorAll(".category-chip").forEach(c => c.classList.remove("active"));
    chip.classList.add("active");
    chip.querySelector("input").checked = true;
    selectedCategory = chip.dataset.key;
    updateSeverityReadout();
  });

  renderCategoryChips();
  updateSeverityReadout();

  /* ---------- AI category suggestion ---------- */
  const aiHint = document.getElementById("aiHint");
  function simulateAiSuggestion(fileCount) {
    if (!aiHint || fileCount === 0) return;
    aiHint.textContent = "Analyzing photo…";
    aiHint.classList.add("show");
    setTimeout(() => {
      const guess = ["pothole", "manhole", "garbage", "streetlight"][Math.floor(Math.random() * 4)];
      aiHint.innerHTML = `AI suggests: <b>${CATEGORY_WEIGHTS[guess].label}</b> — <button type="button" id="acceptAiGuess" class="btn-ghost" style="text-decoration:underline;padding:0;font-size:inherit;">use this</button>`;
      document.getElementById("acceptAiGuess")?.addEventListener("click", () => {
        categoryGrid.querySelector(`.category-chip[data-key="${guess}"]`)?.click();
      });
    }, 900);
  }

  /* ---------- photo dropzone ---------- */
  const dropzone   = document.getElementById("dropzone");
  const fileInput  = document.getElementById("photoInput");
  const previewGrid = document.getElementById("previewGrid");
  let files = [];

  function renderPreviews() {
    previewGrid.innerHTML = "";
    files.forEach((file, i) => {
      const url = URL.createObjectURL(file);
      const div = document.createElement("div");
      div.className = "preview-thumb";
      div.innerHTML = `<img src="${url}" alt="Photo ${i + 1}" /><button type="button" aria-label="Remove" data-i="${i}">✕</button>`;
      previewGrid.appendChild(div);
    });
  }
  function addFiles(list) {
    files = files.concat(Array.from(list).filter(f => f.type.startsWith("image/"))).slice(0, 6);
    renderPreviews();
    simulateAiSuggestion(files.length);
  }
  fileInput?.addEventListener("change", e => addFiles(e.target.files));
  previewGrid?.addEventListener("click", e => {
    const btn = e.target.closest("button[data-i]");
    if (btn) { files.splice(Number(btn.dataset.i), 1); renderPreviews(); }
  });
  ["dragenter","dragover"].forEach(ev => dropzone?.addEventListener(ev, e => { e.preventDefault(); dropzone.classList.add("dragover"); }));
  ["dragleave","drop"].forEach(ev => dropzone?.addEventListener(ev, e => { e.preventDefault(); dropzone.classList.remove("dragover"); }));
  dropzone?.addEventListener("drop", e => addFiles(e.dataTransfer.files));

  /* ---------- geolocation + live map ---------- */
  const locBtn    = document.getElementById("locateBtn");
  const locStatus = document.getElementById("locStatus");
  const mapWrap   = document.getElementById("reportMapWrap");
  let locCoords = null;
  let reportMap = null;
  let reportMarker = null;

  function initReportMap(lat, lng) {
    mapWrap.style.display = "block";
    if (!reportMap) {
      reportMap = L.map("reportMap", { zoomControl: true, scrollWheelZoom: false }).setView([lat, lng], 15);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors", maxZoom: 19,
      }).addTo(reportMap);
      reportMap.on("click", e => {
        locCoords = { lat: e.latlng.lat, lng: e.latlng.lng };
        reportMarker.setLatLng(e.latlng);
        locStatus.classList.add("ok");
        locStatus.innerHTML = `<span class="pulse"></span> Pinned: ${locCoords.lat.toFixed(4)}, ${locCoords.lng.toFixed(4)}`;
      });
    } else {
      reportMap.setView([lat, lng], 15);
    }
    const icon = L.divIcon({
      className: "",
      html: `<div style="width:16px;height:16px;background:var(--gold);border:2px solid #fff;border-radius:50%;box-shadow:0 0 6px rgba(0,0,0,0.5);"></div>`,
      iconSize: [16, 16], iconAnchor: [8, 8],
    });
    if (reportMarker) reportMarker.setLatLng([lat, lng]);
    else reportMarker = L.marker([lat, lng], { icon, draggable: true }).addTo(reportMap);
    reportMarker.on("dragend", e => {
      const p = e.target.getLatLng();
      locCoords = { lat: p.lat, lng: p.lng };
      locStatus.innerHTML = `<span class="pulse"></span> Pinned: ${locCoords.lat.toFixed(4)}, ${locCoords.lng.toFixed(4)}`;
    });
    setTimeout(() => reportMap.invalidateSize(), 100);
  }

  locBtn?.addEventListener("click", () => {
    if (!navigator.geolocation) {
      locStatus.textContent = "Geolocation unavailable — enter address manually.";
      return;
    }
    locStatus.innerHTML = `<span class="pulse"></span> Locating…`;
    navigator.geolocation.getCurrentPosition(
      pos => {
        locCoords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        locStatus.classList.add("ok");
        locStatus.innerHTML = `<span class="pulse"></span> Pinned: ${locCoords.lat.toFixed(4)}, ${locCoords.lng.toFixed(4)}`;
        initReportMap(locCoords.lat, locCoords.lng);
      },
      () => {
        locStatus.classList.remove("ok");
        locStatus.textContent = "Couldn't get location — enter address manually.";
        // Fall back to Bangalore centre
        initReportMap(12.9716, 77.5946);
      }
    );
  });

  /* ---------- form submit ---------- */
  const form  = document.getElementById("reportForm");
  const toast = document.getElementById("toast");

  form?.addEventListener("submit", e => {
    e.preventDefault();
    if (!selectedCategory) {
      severityPill.style.borderColor = "var(--sev-critical)";
      categoryGrid.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    showToast(`Reported — thanks. Reference SETU-${Math.floor(1000 + Math.random() * 9000)}`);
    form.reset(); files = []; renderPreviews();
    categoryGrid.querySelectorAll(".category-chip").forEach(c => c.classList.remove("active"));
    sevChips?.querySelectorAll(".sev-chip").forEach(c => c.classList.remove("active"));
    sevChips?.querySelector("[data-sev='auto']")?.classList.add("active");
    selectedCategory = null; manualSeverity = "auto";
    updateSeverityReadout();
    if (aiHint) aiHint.classList.remove("show");
    locStatus.classList.remove("ok");
    locStatus.innerHTML = `<span class="pulse"></span> Not located yet`;
  });

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3600);
  }

  /* ---------- nearby reports strip ---------- */
  const reportGrid = document.getElementById("reportGrid");
  if (reportGrid) {
    reportGrid.innerHTML = MOCK_REPORTS.filter(r => r.status !== "resolved").slice(0, 6).map(r => {
      const cat = CATEGORY_WEIGHTS[r.category];
      const sev = computeSeverity(r.category, r.confirmations);
      const frac = slaRemainingFraction(r.category, r.reportedAt);
      const hrsLeft = slaHoursLeft(r.category, r.reportedAt);
      return `
        <article class="panel panel-pad report-card">
          <div class="rc-top">
            <div>
              <span class="sev-pill ${sev.tier}"><span class="dot"></span>${sev.label}</span>
              <h3 style="margin-top:.6rem;">${cat.icon} ${cat.label}</h3>
              <div class="rc-meta"><span>${r.area}</span></div>
            </div>
            <div class="sla-ring" style="--ring-pct:${frac}; --ring-color:${ringColorForFraction(frac)};">
              <span class="sla-label">${hrsLeft > 0 ? `<b>${hrsLeft}h</b>left` : `<b>Overdue</b>`}</span>
            </div>
          </div>
          <div class="rc-conf">✓ ${r.confirmations} citizens confirmed nearby</div>
        </article>`;
    }).join("");
  }

  /* ---------- nearby map ---------- */
  if (document.getElementById("nearbyMap")) {
    const nearbyMap = L.map("nearbyMap", { scrollWheelZoom: false }).setView([12.9716, 77.5946], 12);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors", maxZoom: 19,
    }).addTo(nearbyMap);

    const SEV_COLORS = { critical: "#c1553d", high: "#c68a3d", medium: "#c6b23d", low: "#4f9e6e" };
    const BASE_COORDS = [12.9716, 77.5946];
    MOCK_REPORTS.filter(r => r.status !== "resolved").forEach((r, i) => {
      const sev = computeSeverity(r.category, r.confirmations);
      const lat = BASE_COORDS[0] + (Math.sin(i * 1.3) * 0.04);
      const lng = BASE_COORDS[1] + (Math.cos(i * 1.7) * 0.05);
      const color = SEV_COLORS[sev.tier];
      const icon = L.divIcon({
        className: "",
        html: `<div style="width:14px;height:14px;background:${color};border:2px solid rgba(255,255,255,0.8);border-radius:50%;box-shadow:0 0 8px ${color}80;"></div>`,
        iconSize: [14, 14], iconAnchor: [7, 7],
      });
      const cat = CATEGORY_WEIGHTS[r.category];
      L.marker([lat, lng], { icon }).addTo(nearbyMap)
        .bindPopup(`<b>${cat.icon} ${cat.label}</b><br/>${r.area}<br/><span style="color:${color}">● ${sev.label}</span><br/>✓ ${r.confirmations} confirmed`);
    });
  }

  /* ---------- stat counters ---------- */
  document.querySelectorAll("[data-count]").forEach(el => {
    const target = Number(el.dataset.count);
    let cur = 0;
    const step = Math.max(1, Math.round(target / 40));
    const t = setInterval(() => {
      cur = Math.min(cur + step, target);
      el.textContent = cur.toLocaleString();
      if (cur >= target) clearInterval(t);
    }, 25);
  });
});
