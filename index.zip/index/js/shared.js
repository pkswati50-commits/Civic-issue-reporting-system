/* =========================================================
   shared.js
   Category → severity weight map, and mock data used by both
   the citizen report page and the admin ledger.

   Severity is DELIBERATELY not a field the citizen sets directly.
   It is derived from (a) the category's base weight and (b) how
   many other citizens have confirmed the same issue. This is a
   scope decision, not an oversight — see README section on
   "Why isn't severity self-reported?".
   ========================================================= */

const CATEGORY_WEIGHTS = {
  manhole:     { label: "Open Manhole",     icon: "\u26A0\uFE0F", weight: 5, slaHours: 12 },
  pothole:     { label: "Pothole",          icon: "\uD83D\uDD73\uFE0F", weight: 4, slaHours: 48 },
  electrical:  { label: "Exposed Wiring",   icon: "\u26A1", weight: 5, slaHours: 12 },
  streetlight: { label: "Streetlight Out",  icon: "\uD83D\uDCA1", weight: 2, slaHours: 96 },
  garbage:     { label: "Garbage Pileup",   icon: "\uD83D\uDDD1\uFE0F", weight: 3, slaHours: 72 },
  water:       { label: "Water Leakage",    icon: "\uD83D\uDEB0", weight: 4, slaHours: 36 },
  drainage:    { label: "Blocked Drain",    icon: "\uD83C\uDF27\uFE0F", weight: 3, slaHours: 60 },
  signage:     { label: "Damaged Signage",  icon: "\uD83D\uDEA7", weight: 2, slaHours: 96 },
  treefall:    { label: "Fallen Tree",      icon: "\uD83C\uDF33", weight: 4, slaHours: 24 },
  other:       { label: "Other",            icon: "\uD83D\uDCCC", weight: 2, slaHours: 96 },
};

/**
 * Turn a base category weight (1-5) plus a confirmation count into
 * a severity tier. More confirmations nudge severity up, capped at
 * "critical" — this is what "citizen-verified" actually buys you.
 */
function computeSeverity(categoryKey, confirmations = 0) {
  const base = CATEGORY_WEIGHTS[categoryKey]?.weight ?? 2;
  const bump = confirmations >= 15 ? 2 : confirmations >= 6 ? 1 : 0;
  const score = Math.min(base + bump, 5);
  if (score >= 5) return { tier: "critical", label: "Critical", score };
  if (score >= 4) return { tier: "high", label: "High", score };
  if (score >= 3) return { tier: "medium", label: "Medium", score };
  return { tier: "low", label: "Low", score };
}

/** Fraction of the SLA window remaining, 0..1 (1 = just reported, 0 = overdue). */
function slaRemainingFraction(categoryKey, reportedAtISO) {
  const slaHours = CATEGORY_WEIGHTS[categoryKey]?.slaHours ?? 72;
  const reportedAt = new Date(reportedAtISO).getTime();
  const deadline = reportedAt + slaHours * 3600 * 1000;
  const now = Date.now();
  const remaining = deadline - now;
  const total = slaHours * 3600 * 1000;
  return Math.max(0, Math.min(1, remaining / total));
}

function slaHoursLeft(categoryKey, reportedAtISO) {
  const slaHours = CATEGORY_WEIGHTS[categoryKey]?.slaHours ?? 72;
  const reportedAt = new Date(reportedAtISO).getTime();
  const deadline = reportedAt + slaHours * 3600 * 1000;
  const hrs = Math.round((deadline - Date.now()) / 3600000);
  return hrs;
}

function ringColorForFraction(frac) {
  if (frac <= 0.15) return "var(--sev-critical)";
  if (frac <= 0.4) return "var(--sev-high)";
  if (frac <= 0.7) return "var(--sev-medium)";
  return "var(--sev-low)";
}

/* --- mock ledger data for the admin dashboard / nearby-reports strip --- */
const MOCK_REPORTS = [
  {
    id: "SETU-1042", category: "manhole", area: "Jayanagar 4th Block",
    reportedAt: isoHoursAgo(9), confirmations: 18, status: "open",
    citizen: "R. Kumar", photoCount: 2,
  },
  {
    id: "SETU-1041", category: "pothole", area: "Outer Ring Rd, Marathahalli",
    reportedAt: isoHoursAgo(30), confirmations: 7, status: "in_progress",
    citizen: "A. Fernandes", photoCount: 3,
  },
  {
    id: "SETU-1039", category: "streetlight", area: "HSR Layout Sector 2",
    reportedAt: isoHoursAgo(60), confirmations: 3, status: "open",
    citizen: "S. Iyer", photoCount: 1,
  },
  {
    id: "SETU-1037", category: "garbage", area: "Koramangala 5th Block",
    reportedAt: isoHoursAgo(50), confirmations: 11, status: "open",
    citizen: "M. Bhat", photoCount: 4,
  },
  {
    id: "SETU-1033", category: "water", area: "Indiranagar 100ft Rd",
    reportedAt: isoHoursAgo(20), confirmations: 5, status: "in_progress",
    citizen: "P. Rao", photoCount: 2,
  },
  {
    id: "SETU-1029", category: "electrical", area: "Whitefield Main Rd",
    reportedAt: isoHoursAgo(5), confirmations: 9, status: "open",
    citizen: "K. Reddy", photoCount: 2,
  },
  {
    id: "SETU-1021", category: "drainage", area: "BTM Layout 2nd Stage",
    reportedAt: isoHoursAgo(80), confirmations: 4, status: "resolved",
    citizen: "N. Das", photoCount: 2,
  },
  {
    id: "SETU-1018", category: "treefall", area: "Malleshwaram 8th Cross",
    reportedAt: isoHoursAgo(14), confirmations: 6, status: "open",
    citizen: "V. Shetty", photoCount: 3,
  },
];

function isoHoursAgo(h) {
  return new Date(Date.now() - h * 3600 * 1000).toISOString();
}